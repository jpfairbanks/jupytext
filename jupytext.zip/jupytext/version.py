"""Jupytext's version number"""

__version__ = '0.9.0rc0'
