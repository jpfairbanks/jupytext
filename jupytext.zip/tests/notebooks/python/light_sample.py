# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py
#     text_representation:
#       format_name: light
#       format_version: '1.2'
# ---

# # Sample notebook

a = 1
b = 2
a + b
