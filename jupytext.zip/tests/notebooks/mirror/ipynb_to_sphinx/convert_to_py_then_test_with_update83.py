# ---
# jupyter:
#   jupytext:
#     text_representation:
#       format_version: '1.1'
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %%time

print('asdf')

"""
Thanks for jupytext!
"""


